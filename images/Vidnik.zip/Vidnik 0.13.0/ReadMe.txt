// Read Me April 30, 2008

What Vidnik is:

Vidnik is a simple tool for making movies from your Mac's camera and 
uploading them to YouTube.

Vidnik's advantage:

It records movies in the format that YouTube prefers. That is a half
dozen encoding settings you do not have to worry about.

This is Vidnik, version 0.13.0

This version expresses my original idea. Now, I'd like constructive crticism:
What would make this application better?

To Install:

Vidnik is an ordinary self-contained application. Drag it where you
like.

By:
David Phillip Oster. Please email comments and suggestions to me at:

oster@google.com

To use:

Select a new movie from the list on the left of the window. If there are none, press the "+" button at the bottom of the window, or choose "New Movie" from the File menu.

Press the "Record" button to start recording. Press it again to stop.

Fill in a title, category, tags, and description.

When you have a set of movies that you like, press the Upload button. It
uploads all the movies that are ready to upload.

Cancelling the upload of any of the movies cancels the upload session.

When the upload is done, the button will re-enable.

Save the Vidnik document, and it will remember which ones you've
uploaded, and which not.

Going beyond Vidnik:

You can drag movies created in other programs into the playlist pane of the
Vidnik window, using Vidnik just as a bulk uploader.

You can use the contextual menu (Right-click or Command-click) to reveal the  original movie file in the Finder, then use some other program to edit it, using Vidnik just for the initial movie capture.

Secrets:

A few, infrequently used commands, are revealed by holding down the option
key as you look at the menu bar:
  <Option> File Menu for the New Document command. (instead of New Movie)
  <Option> Web Menu for the Forget Account command (instead of Change Account)

What is missing:

  * splitting, and joining video segments.
  * synchronizing the Vidnik document with your YouTube account.
  * Vidnik's online help needs work.

This version works with OS X 10.4 and up.

  You can't edit the title and description of a previously uyploaded movie, and have just those changes sent to YouTube,
  You can't do playlist management (YouTube lets you create more than one playlist, send the order of existing clips to YouTube.)
  

